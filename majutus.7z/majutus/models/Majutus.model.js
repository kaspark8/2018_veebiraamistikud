// Majutus.model.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const Majutus = new Schema({
  name: {
    type: String
  },
  price: {
     type: Number
  },
  score: {
     type: Number
  },
  address: {
     type: String
  },
  contact: {
     type: String
  }
},{
    collection: 'majutused'
});

module.exports = mongoose.model('Majutus', Majutus);