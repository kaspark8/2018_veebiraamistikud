// MajutusRoute.js

const express = require('express');
const app = express();
const MajutusRouter = express.Router();
const Majutus = require('../models/Majutus.model');

MajutusRouter.route('/').get(function (req, res) {
   Majutus.find(function (err, majutused){
      if(err){
        console.log(err);
      }
      else {
        res.render('index', {majutused: majutused});
      }
    });
});

MajutusRouter.route('/create').get(function (req, res) {
   res.render('create');
 });

 MajutusRouter.route('/post').post(function (req, res) {
   const majutus = new Majutus(req.body);
   console.log(majutus);
   majutus.save()
     .then(majutus => {
     res.redirect('/majutused');
     })
     .catch(err => {
     res.status(400).send("unable to save to database");
     });
 });

MajutusRouter.route('/edit/:id').get(function (req, res) {
   const id = req.params.id;
   Majutus.findById(id, function (err, majutus){
       res.render('edit', {majutus: majutus});
   });
 });

 MajutusRouter.route('/update/:id').post(function (req, res) {
   Majutus.findById(req.params.id, function(err, majutus) {
     if (!majutus)
       return next(new Error('Could not load Document'));
     else {
       // do your updates here
       majutus.name = req.body.name;
       majutus.price = req.body.price;
       majutus.score = req.body.score;
       majutus.address = req.body.address;
       majutus.contact = req.body.contact;
 
       majutus.save().then(majutus => {
           res.redirect('/majutused');
       })
       .catch(err => {
             res.status(400).send("unable to update the database");
       });
     }
   });
 });

 MajutusRouter.route('/delete/:id').get(function (req, res) {
   Majutus.findByIdAndRemove({_id: req.params.id},
        function(err, majutus){
         if(err) res.json(err);
         else res.redirect('/majutused');
     });
 });

module.exports = MajutusRouter;